package projet_hotel;
import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;

public class etoile extends JFrame implements ActionListener{

    private JPanel contentPane;
    private JTextField textFieldNom;
    private JTextField textFieldPrenom;
    private JDateChooser dateChooserEntree;
    private JDateChooser dateChooserSortie;
    private JSlider sliderConfort;
    private JSlider sliderSecurite;
    private JSlider sliderAnimation;
    private JSlider sliderProprete;
    private JSlider sliderAnnee;
    private JTextField textFieldCommentaire;
    private JButton buttonValider;
    private JButton buttonAnnuler;
    private JButton buttonRetour;
    public etoile() {
        setForeground(Color.BLACK);
        setBackground(new Color(240, 240, 240));
        setTitle("Welcome");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 286, 40);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 331, 516);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel_6 = new JLabel("New label");
        ImageIcon img = new ImageIcon(getClass().getResource("/hotel.jpg"));
        lblNewLabel_6.setIcon(img);
        lblNewLabel_6.setBounds(10, 21, 289, 451);
        panel.add(lblNewLabel_6);

        buttonValider = new JButton("Valider");
        buttonValider.setForeground(Color.DARK_GRAY);
        buttonValider.setBackground(Color.GREEN);
        buttonValider.addActionListener(this);
        buttonValider.setBounds(351, 481, 125, 35);
        contentPane.add(buttonValider);

        buttonAnnuler = new JButton("Annuler");
        buttonAnnuler.setForeground(Color.DARK_GRAY);
        buttonAnnuler.setBackground(new Color(255, 0, 0));
        buttonAnnuler.addActionListener(this);
        buttonAnnuler.setBounds(512, 481, 110, 35);
        contentPane.add(buttonAnnuler);
        
        buttonRetour = new JButton("Retour");
        buttonRetour.setForeground(Color.DARK_GRAY);
        buttonRetour.setBackground(new Color(255, 128, 0));
        buttonRetour.addActionListener(this);
        buttonRetour.setBounds(643, 44, 85, 36);
        contentPane.add(buttonRetour);

        JLabel labelDateEntree = new JLabel("Date d'entrée :");
        labelDateEntree.setBounds(341, 149, 71, 13);
        contentPane.add(labelDateEntree);

        dateChooserEntree = new JDateChooser();
        dateChooserEntree.setBounds(431, 144, 166, 29);
        contentPane.add(dateChooserEntree);

        JLabel labelDateSortie = new JLabel("Date de sortie :");
        labelDateSortie.setBounds(341, 198, 71, 13);
        contentPane.add(labelDateSortie);

        dateChooserSortie = new JDateChooser();
        dateChooserSortie.setBounds(431, 198, 166, 20);
        contentPane.add(dateChooserSortie);

        JLabel labelConfort = new JLabel("Confort");
        labelConfort.setBounds(341, 221, 71, 35);
        contentPane.add(labelConfort);

        sliderConfort = new JSlider();
        sliderConfort.setMinimum(1);
        sliderConfort.setMaximum(5);
        sliderConfort.setBounds(431, 228, 166, 22);
        contentPane.add(sliderConfort);

        JLabel labelSecurite = new JLabel("Sécurité");
        labelSecurite.setBounds(341, 270, 71, 24);
        contentPane.add(labelSecurite);

        sliderSecurite = new JSlider();
        sliderSecurite.setMinimum(1);
        sliderSecurite.setMaximum(5);
        sliderSecurite.setBounds(436, 270, 161, 22);
        contentPane.add(sliderSecurite);

        JLabel labelAnimation = new JLabel("Animation ");
        labelAnimation.setBounds(341, 319, 49, 22);
        contentPane.add(labelAnimation);

        sliderAnimation = new JSlider();
        sliderAnimation.setMinimum(1);
        sliderAnimation.setMaximum(5);
        sliderAnimation.setBounds(431, 319, 166, 22);
        contentPane.add(sliderAnimation);

        JLabel labelProprete = new JLabel("Propreté");
        labelProprete.setBounds(341, 351, 59, 22);
        contentPane.add(labelProprete);

        sliderProprete = new JSlider();
        sliderProprete.setMinimum(1);
        sliderProprete.setMaximum(5);
        sliderProprete.setBounds(431, 351, 166, 22);
        contentPane.add(sliderProprete);
        
        JLabel labelAnnee = new JLabel("Année");
        labelAnnee.setBounds(345, 396, 49, 13);
        contentPane.add(labelAnnee);

        sliderAnnee = new JSlider();
        sliderAnnee.setMinimum(2023);  // Vous pouvez ajuster les valeurs minimale et maximale selon vos besoins
        sliderAnnee.setMaximum(2030);
        sliderAnnee.setBounds(431, 383, 166, 22);
        contentPane.add(sliderAnnee);

        JLabel labelCommentaire = new JLabel("Votre commentaire");
        labelCommentaire.setBounds(341, 442, 85, 29);
        contentPane.add(labelCommentaire);

        textFieldCommentaire = new JTextField();
        textFieldCommentaire.setBounds(433, 445, 189, 24);
        contentPane.add(textFieldCommentaire);
        textFieldCommentaire.setColumns(10);

        JLabel labelNotreHotel = new JLabel("WELCOME");
        labelNotreHotel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
        labelNotreHotel.setBounds(416, 10, 125, 22);
        contentPane.add(labelNotreHotel);

        JLabel labelNom = new JLabel("Nom");
        labelNom.setBounds(341, 56, 45, 13);
        contentPane.add(labelNom);

        JLabel labelPrenom = new JLabel("Prénom");
        labelPrenom.setBounds(341, 99, 49, 22);
        contentPane.add(labelPrenom);

        textFieldNom = new JTextField();
        textFieldNom.setColumns(10);
        textFieldNom.setBounds(426, 51, 171, 24);
        contentPane.add(textFieldNom);

        textFieldPrenom = new JTextField();
        textFieldPrenom.setColumns(10);
        textFieldPrenom.setBounds(431, 99, 166, 24);
        contentPane.add(textFieldPrenom);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    @Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonRetour) {
            // Retour à la fenêtre principale
            fenetre menuPrincipal = new fenetre();
            menuPrincipal.setVisible(true);
            dispose(); // Ferme la fenêtre actuelle
        } else if (e.getSource() == buttonValider) {
            validerActionPerformed();
        } else if (e.getSource() == buttonAnnuler) {
            annulerAction();
        }
    }
    private void annulerAction() {
	    // Réinitialiser les champs
	    textFieldNom.setText("");
	    textFieldPrenom.setText("");
	    dateChooserEntree.setDate(null);
	    dateChooserSortie.setDate(null);
	    sliderConfort.setValue(1);
	    sliderSecurite.setValue(1);
	    sliderAnimation.setValue(1);
	    sliderProprete.setValue(1);
	    sliderAnnee.setValue(1);
	    textFieldCommentaire.setText("");
	}
	public void validerActionPerformed() {
	    System.out.println("Début de validerActionPerformed");
	    String nom = textFieldNom.getText();
	    String prenom = textFieldPrenom.getText();
	    Date dateEntree = dateChooserEntree.getDate();
	    Date dateSortie = dateChooserSortie.getDate();
	    int confort = sliderConfort.getValue();
	    int securite = sliderSecurite.getValue();
	    int animation = sliderAnimation.getValue();
	    int proprete = sliderProprete.getValue();
	    int annee = sliderAnnee.getValue();
	    String commentaire = textFieldCommentaire.getText();

	    try (Connection connection = connect.getCon()) {
	        String sql = "INSERT INTO client (nom, prenom, date_entree, date_sortie, confort, securite, animation, proprete, annee, commentaire) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	            preparedStatement.setString(1, nom);
	            preparedStatement.setString(2, prenom);
	            preparedStatement.setDate(3, new java.sql.Date(dateEntree.getTime()));
	            preparedStatement.setDate(4, new java.sql.Date(dateSortie.getTime()));
	            preparedStatement.setInt(5, confort);
	            preparedStatement.setInt(6, securite);
	            preparedStatement.setInt(7, animation);
	            preparedStatement.setInt(8, proprete);
	            preparedStatement.setInt(9, annee);
	            preparedStatement.setString(10, commentaire);

	            System.out.println("Connexion à la base de données réussie");
	            preparedStatement.executeUpdate();

	            System.out.println("Requête exécutée avec succès");
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        System.out.println("Erreur SQL : " + ex.getMessage());
	    }
	    System.out.println("Fin de validerActionPerformed");
	 // Afficher les valeurs dans une boîte de dialogue
	    String message = "Nom: " + nom + "\nPrénom: " + prenom + "\nDate d'entrée: " + dateEntree
	            + "\nDate de sortie: " + dateSortie + "\nConfort: " + confort + "\nSécurité: " + securite
	            + "\nAnimation: " + animation + "\nPropreté: " + proprete + "\nVotre commentaire: " + commentaire;
	    javax.swing.JOptionPane.showMessageDialog(this, message, "Valeurs saisies", javax.swing.JOptionPane.INFORMATION_MESSAGE);
	}


}