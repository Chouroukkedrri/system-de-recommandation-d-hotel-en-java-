package projet_hotel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.CombinedDomainCategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
public class graphe extends JFrame {
	private JButton buttonRetour;
	public graphe() {
        super("Estimation des Critéres par Année");
        // Se connecter à la base de données
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "")) {
            // Récupérer les données de la base de données pour chaque année
            Map<Integer, Double> dataConfort = fetchData(connection, "confort");
            Map<Integer, Double> dataSecurite = fetchData(connection, "securite");
            Map<Integer, Double> dataAnimation = fetchData(connection, "animation");
            Map<Integer, Double> dataProprete = fetchData(connection, "proprete");
            // Créer les graphiques
            JFreeChart chartConfort = createHistogramChart(dataConfort, "Confort");
            JFreeChart chartSecurite = createHistogramChart(dataSecurite, "Sécurité");
            JFreeChart chartAnimation = createHistogramChart(dataAnimation, "Animation");
            JFreeChart chartProprete = createHistogramChart(dataProprete, "Propreté");
            // Créer les panneaux
            JPanel panelConfort = createChartPanel(chartConfort);
            JPanel panelSecurite = createChartPanel(chartSecurite);
            JPanel panelAnimation = createChartPanel(chartAnimation);
            JPanel panelProprete = createChartPanel(chartProprete);
            // Créer le layout avec 2 lignes et 2 colonnes
            GridLayout gridLayout = new GridLayout(2, 2);
            setLayout(gridLayout);
            // Ajouter les panneaux à la fenêtre
            add(panelConfort);
            add(panelSecurite);
            add(panelAnimation);
            add(panelProprete);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	private Map<Integer, Double> fetchData(Connection connection, String critere) throws SQLException {
        Map<Integer, Double> data = new HashMap<>();

        // Exécuter la requête SQL pour récupérer les données de la table client
        String query = "SELECT annee, " + critere + " FROM client";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            Map<Integer, Integer> count = new HashMap<>();
            while (resultSet.next()) {
                int annee = resultSet.getInt("annee");
                int note = resultSet.getInt(critere);

                // Ajouter la note à la somme pour l'année correspondante
                data.merge(annee, (double) note, Double::sum);

                // Compter le nombre de notes pour chaque année
                count.merge(annee, 1, Integer::sum);
            }

            // Calculer la moyenne pour chaque année
            for (int annee : data.keySet()) {
                double totalNote = data.get(annee);
                int notesCount = count.get(annee);
                data.put(annee, totalNote / notesCount);
            }
        }
        return data;
    }
	private JFreeChart createHistogramChart(Map<Integer, Double> data, String title) {
        JFreeChart chart = ChartFactory.createBarChart(
                title,                           // Titre du graphique
                "Année",                         // Axe des X : Année
                "Note",                  // Axe des Y : Moyenne Note
                createDataset(data),             // Ensemble de données
                PlotOrientation.VERTICAL,        // Orientation du graphique
                true,                            // Afficher la légende
                true,                            // Activer les outils (zoom, etc.)
                false                            // Ne pas générer d'URL pour le graphique
        );
        CategoryPlot plot = chart.getCategoryPlot();
        CategoryAxis xAxis = plot.getDomainAxis();
        xAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        return chart;
    }
	private CategoryDataset createDataset(Map<Integer, Double> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int annee : data.keySet()) {
            double moyenneNote = data.get(annee);
            dataset.addValue(moyenneNote, "Estimation", String.valueOf(annee));
        }

        return dataset;
    }
	private JPanel createChartPanel(JFreeChart chart) {
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(400, 300));
        return chartPanel;
    }
	
}
