package projet_hotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connect {

    private static Connection con;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded successfully");

            // Database connection information
            String url = "jdbc:mysql://localhost:3306/hotel";
            String user = "root";
            String passwd = "";
            con = DriverManager.getConnection(url, user, passwd);
            System.out.println("Connected to the database");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle the exception based on your application's requirements
        }
    }

    public static Connection getCon() {
        return con;
    }

    public static void closeConnection() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Connection closed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception based on your application's requirements
        }
    }
}